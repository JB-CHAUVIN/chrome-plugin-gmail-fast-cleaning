# Gmail - chrome extension to delete all emails from a specific sender
## This gmail extension allows you to delete all emails from a specific sender with just one shortcut.


Too many emails in your Gmail inbox 🤯 ?

Introducing the ultimate solution for anyone looking to clean up their Gmail inbox quickly and easily - our powerful Chrome extension! Say goodbye to cluttered and disorganized inboxes with our simple, yet effective tool that helps you stay on top of your emails and stay focused on what really matters 👌.

🔥 With just one simple shortcut - CTRL + D - you can quickly and easily delete all emails from a specific sender, making it incredibly fast and easy to keep your inbox clean and organized. Our extension automatically fills in the sender's username in the Gmail search box, eliminating the need for manual input and helping you save valuable time and effort.

ℹ️ HOW TO USE IT ?
1) Install the extension
2) Open a gmail email
3) Hit the shortcut and see the result

❗️❗️❗️YOU NEED TO CUSTOMIZE THE SHORTCUT SO THAT THE EXTENSION WORKS : chrome://extensions/shortcuts ❗️❗️❗️

Whether you're a busy professional looking to streamline your workflow, a student trying to stay on top of your coursework, or simply someone who wants a cleaner and more efficient Gmail experience, our extension is the perfect solution for you. It's incredibly easy to use, and the benefits are immediate - no more wasting time sifting through unwanted emails or cluttered inboxes!

So why wait? Download our Gmail inbox cleaning extension today and see for yourself just how easy and effective managing your emails can be. With our powerful tool at your fingertips, you'll wonder how you ever managed without it!
